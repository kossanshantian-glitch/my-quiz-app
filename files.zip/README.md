# クイズアプリ セットアップ手順

スマホ対応・Google スプレッドシート自動保存付きのクイズアプリです。

---

## ファイル構成

```
quiz-app/
├── index.html      # メインHTML
├── style.css       # スタイル
├── app.js          # アプリのロジック
├── quiz-data.js    # 問題データ（ここを編集）
└── gas-code.gs     # Google Apps Script コード
```

---

## STEP 1 — GitHubにアップロード

1. [github.com](https://github.com) にログイン
2. **New repository** をクリック
3. リポジトリ名を入力（例: `my-quiz-app`）
4. **Public** を選択 → **Create repository**
5. 4つのファイルをアップロード：
   - `index.html`
   - `style.css`
   - `app.js`
   - `quiz-data.js`
   > ※ `gas-code.gs` はアップロード不要

---

## STEP 2 — GitHub Pages を有効化

1. リポジトリの **Settings** タブ → **Pages** へ
2. Source: **Deploy from a branch**
3. Branch: **main** / **/ (root)** を選択 → **Save**
4. 数分後に `https://あなたのユーザー名.github.io/my-quiz-app/` でアクセスできます

---

## STEP 3 — Google スプレッドシートの準備

1. [Google スプレッドシート](https://sheets.google.com) を開く
2. 新しいスプレッドシートを作成
3. URLから **スプレッドシートID** をコピーする
   - URL例: `https://docs.google.com/spreadsheets/d/`**`1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms`**`/edit`
   - 太字部分がID

---

## STEP 4 — Google Apps Script の設定

1. [script.google.com](https://script.google.com) を開く
2. **新しいプロジェクト** をクリック
3. `gas-code.gs` の内容をコピー＆ペースト
4. **SPREADSHEET_ID** の部分を STEP3 でコピーしたIDに変更：
   ```javascript
   const SPREADSHEET_ID = '1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms';
   ```
5. 💾 **保存**（Ctrl+S）

---

## STEP 5 — デプロイ（公開）

1. 右上の **デプロイ** → **新しいデプロイ**
2. 種類: **ウェブアプリ**
3. 設定:
   - **次のユーザーとして実行**: 自分
   - **アクセスできるユーザー**: 全員
4. **デプロイ** をクリック
5. 権限の確認画面 → **アクセスを許可**
6. 表示された **ウェブアプリのURL** をコピー

---

## STEP 6 — クイズアプリにURLを登録

1. スマホ/PCで GitHub Pages のURLを開く
2. 右下の ⚙️ ボタンをタップ
3. STEP5 でコピーした URL を貼り付けて **保存**

---

## 問題を変更する方法

`quiz-data.js` を編集します：

```javascript
const QUIZ_DATA = [
  {
    question: "問題文をここに書く",
    choices: ["選択肢A", "選択肢B", "選択肢C", "選択肢D"],
    correct: 0,   // ← 正解の選択肢番号（0=A, 1=B, 2=C, 3=D）
    explanation: "解説文をここに書く"
  },
  // 続けて問題を追加...
];
```

ファイルを編集して GitHub にアップロードし直すと、問題が更新されます。

---

## よくある質問

**Q: スプレッドシートに保存できない**
→ GAS の URL が正しく登録されているか確認。デプロイ設定で「全員がアクセス可能」になっているか確認。

**Q: GitHub Pages のURLが開かない**
→ Settings → Pages で有効化されているか確認。有効化後は数分かかる場合があります。

**Q: 問題を増やしたい**
→ `quiz-data.js` にオブジェクトを追加するだけで OK です。問題数の上限はありません。
