// ============================================================
//  Google Apps Script (GAS) コード
//  使い方: https://script.google.com/home で新規スクリプトを作成し
//  このコードをコピー＆ペーストして保存→デプロイしてください
// ============================================================

// ▼ 保存先のスプレッドシートIDを入れてください
//   スプレッドシートのURLの /d/XXXXXXXX/edit の XXXXXXXX の部分です
const SPREADSHEET_ID = 'ここにスプレッドシートIDを貼り付け';

// ▼ シート名（変更可能）
const SHEET_NAME = 'クイズ結果';

// ============================================================
//  POST リクエストを受け取って行を追加する
// ============================================================
function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sheet = ss.getSheetByName(SHEET_NAME);

    // シートがなければ作成してヘッダーを追加
    if (!sheet) {
      sheet = ss.insertSheet(SHEET_NAME);
      sheet.appendRow([
        '日時', '名前', '正解数', '問題数', '正答率(%)', '所要時間(秒)',
        ...Array.from({length: 10}, (_, i) => `Q${i+1}_問題`),
        ...Array.from({length: 10}, (_, i) => `Q${i+1}_正解`),
        ...Array.from({length: 10}, (_, i) => `Q${i+1}_回答`),
        ...Array.from({length: 10}, (_, i) => `Q${i+1}_結果`),
      ]);
      // ヘッダー行を固定・装飾
      sheet.setFrozenRows(1);
      sheet.getRange(1, 1, 1, sheet.getLastColumn())
        .setBackground('#4a4a8a')
        .setFontColor('#ffffff')
        .setFontWeight('bold');
    }

    // 基本データ
    const row = [
      data.timestamp,
      data.name,
      data.score,
      data.total,
      data.percent,
      data.elapsed,
    ];

    // 問題ごとの詳細（最大10問）
    const details = (data.details || []).slice(0, 10);
    const qTexts    = details.map(d => d.q);
    const corrects  = details.map(d => d.correct);
    const answers   = details.map(d => d.answer);
    const results   = details.map(d => d.result);

    // 10問分に揃える（空白で埋める）
    while (qTexts.length  < 10) qTexts.push('');
    while (corrects.length < 10) corrects.push('');
    while (answers.length  < 10) answers.push('');
    while (results.length  < 10) results.push('');

    row.push(...qTexts, ...corrects, ...answers, ...results);
    sheet.appendRow(row);

    // 正解セルを緑、不正解セルを赤に色付け
    const lastRow = sheet.getLastRow();
    const startCol = 7 + 30; // 結果列の開始（Q1_結果）
    results.forEach((r, i) => {
      const col = 7 + 30 + i; // ヘッダー6列 + Q*3種 * 10 + i
      // 実際の列番号（1-indexed）
      // 構造: 日時(1) 名前(2) 正解(3) 問題数(4) %(5) 秒(6)
      //        Q1_問(7)..Q10_問(16) Q1_正(17)..Q10_正(26) Q1_答(27)..Q10_答(36) Q1_結(37)..Q10_結(46)
      const resultCol = 37 + i;
      const cell = sheet.getRange(lastRow, resultCol);
      if (r === '○') {
        cell.setBackground('#d4edda').setFontColor('#155724');
      } else if (r === '×') {
        cell.setBackground('#f8d7da').setFontColor('#721c24');
      }
    });

    return ContentService
      .createTextOutput(JSON.stringify({ status: 'ok' }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ status: 'error', message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// ============================================================
//  GET リクエスト（動作確認用）
// ============================================================
function doGet(e) {
  return ContentService
    .createTextOutput('✅ Quiz GAS は正常に動作しています')
    .setMimeType(ContentService.MimeType.TEXT);
}
